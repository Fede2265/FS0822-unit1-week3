package gestioneCatalogo;

import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;

import models.Archivio;
import models.Elemento;
import models.Libro;
import models.Periodicita;
import models.Prestito;
import models.Rivista;
import models.Tipo;
import models.Utente;
import dao.ElementoDAO;

public class Main {

	public static void main(String[] args) {
		String s = System.lineSeparator();
		
//		ISTANZE ELEMENTO
		Elemento e1 = new Libro("1234", "Twilight", LocalDate.of(2021, 1, 2), 240, "Stephenie Meyer", "Romantico");
		Elemento e2 = new Libro("5432", "Pinocchio", LocalDate.of(2022, 1, 2), 180, "Carlo Collodi", "Bambini");
		Elemento e3 = new Rivista("4321", "Uomini e Donne", LocalDate.of(2022, 1, 2), 20, Periodicita.SETTIMANALE);
		Elemento e4 = new Rivista("6789", "Chi", LocalDate.of(2022, 1, 2), 20, Periodicita.MENSILE);
		
//		SAVE ELEMENTO
		ElementoDAO.saveElement(e1);
		ElementoDAO.saveElement(e2);
		ElementoDAO.saveElement(e3);
		ElementoDAO.saveElement(e4);
		System.err.println(s);
		
//		METODI DAO
		ElementoDAO.deleteByISBN("6789");
		System.err.println(s);
		ElementoDAO.getByISBN("5432");
		System.err.println(s);
		ElementoDAO.getByAnno(2022);
		System.err.println(s);
		ElementoDAO.getByAutore("Carlo Collodi");
		System.err.println(s);
		ElementoDAO.getByTitolo("Pi");
		System.err.println(s);
		
//		ISTANZA UTENTE
		Utente u1 = new Utente("Giovanni", "Rossi", LocalDate.of(2002, 1, 4), 123);
		Utente u2 = new Utente("Giulia", "Verdi", LocalDate.of(2001, 10, 6), 456);
		
//		SAVE UTENTE
		ElementoDAO.saveElement(u1);
		ElementoDAO.saveElement(u2);
		
//		ISTANZA PRESTITO
		Prestito p1 = new Prestito(u1, e1, LocalDate.of(2023, 1, 25), LocalDate.of(2023, 6, 4));
		Prestito p2 = new Prestito(u2, e2, LocalDate.of(2023, 1, 30), null);
		Prestito p3 = new Prestito(u1, e1, LocalDate.of(2023, 1, 25), LocalDate.of(2023, 6, 4));
		Prestito p4 = new Prestito(u2, e3, LocalDate.of(2022, 1, 30), null);
		
//		SAVE PRESTITO
		ElementoDAO.saveElement(p1);
		ElementoDAO.saveElement(p2);
		ElementoDAO.saveElement(p3);
		ElementoDAO.saveElement(p4);
		
//		METODI DAO
		System.err.println(s);
		ElementoDAO.getElementiPrestati(456);
		System.err.println(s);
		ElementoDAO.getPrestitiScaduti();
		
}
}