package models;

public enum Tipo {
	ISBN, AUTORE, TITOLO, ANNO
}
