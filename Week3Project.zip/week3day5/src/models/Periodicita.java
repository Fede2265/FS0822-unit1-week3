package models;

public enum Periodicita {
	SETTIMANALE, MENSILE, SEMESTRALE
}